#pragma once
#include "../Feature.h"

class CAutoQueue
{
public:
	void Run();
};

ADD_FEATURE(CAutoQueue, AutoQueue);