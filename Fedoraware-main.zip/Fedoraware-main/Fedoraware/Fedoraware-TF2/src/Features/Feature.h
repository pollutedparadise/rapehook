#pragma once
#include "Vars.h"

#define ADD_FEATURE(cClass, szName) namespace F { inline cClass szName; }
