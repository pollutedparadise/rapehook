#pragma once

class CTFGameRules
{

};