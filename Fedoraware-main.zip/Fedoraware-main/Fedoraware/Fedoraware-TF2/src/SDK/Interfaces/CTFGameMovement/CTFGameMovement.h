#pragma once
#include "../GameMovement/GameMovement.h"

class CTFGameMovement : public CGameMovement {};
