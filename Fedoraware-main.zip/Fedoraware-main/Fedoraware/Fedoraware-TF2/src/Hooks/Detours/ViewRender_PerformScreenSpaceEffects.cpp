#include "../Hooks.h"

MAKE_HOOK(ViewRender_PerformScreenSpaceEffects, S::ViewRender_PerformScreenSpaceEffects(), void, __fastcall, void* ecx, void* edx, int x, int y, int w, int h)
{
	// Do nothing.
}